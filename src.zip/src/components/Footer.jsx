import React from "react";


function Footer() {
  return (
    <div className="footer">
      <p className="text-center text-white m-3" >
        All Rights Reserved &copy; 
        <b>Jadoo.com</b>&reg;2023
      </p>
    </div>
  );
}

export default Footer;
